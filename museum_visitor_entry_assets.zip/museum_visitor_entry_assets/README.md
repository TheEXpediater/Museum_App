# Museum Visitor Entry Asset Pack

These assets were extracted/derived from the user-provided UI reference screenshot.

## Important
The reference screenshot is a flattened image. The original source layers and vectors are not available, so:
- character PNGs are reconstructed transparent cutouts;
- decorative assets are crops;
- phone-scene strips are visual references and should not be treated as a complete background;
- buttons/cards must be rebuilt natively in Jetpack Compose.

## Recommended layer order
1. Full-screen museum scene background.
2. Decorative leaves/grass/dots.
3. Character illustrations.
4. Native role cards/buttons.
5. Native text and accessibility semantics.

## Click behavior
Do NOT make the illustration itself the only click target.
Create full-width/full-card Compose click targets:
- Guest card -> Guest Information
- Student card -> Student Login / Student flow
- Administrator Login -> existing admin login
- Sign in as control -> optional account selector or destination specified by navigation

Use the image only as visual content inside the clickable card.

## Android
Copy into:
android/app/src/main/assets/visitor_entry/

Then reference with:
file:///android_asset/visitor_entry/<folder>/<filename>

Prefer Material Icons for ordinary UI/navigation symbols if the existing project already uses them.
