# CODEX PROMPT — SENIOR KOTLIN / JETPACK COMPOSE ENGINEER

Act as a senior Android, Kotlin, Jetpack Compose, Material 3, Navigation Compose, accessibility, and mobile UX engineer.

Work directly inside the existing Museum Guide repository. Inspect the current implementation before changing anything. Preserve all existing administrator functionality, backend APIs, authentication, visitor routing, and working visitor screens.

## SOURCE OF TRUTH

The repository already contains a visitor architecture with separate entry, guest, student, navigation, and asset components. Do not create a parallel app or duplicate repositories, Retrofit clients, session stores, navigation graphs, or authentication flows.

Use the supplied `museum_visitor_entry_assets` package as the visual reference for the redesigned Visitor Entry screen.

The supplied assets are layered visual assets:
- `characters/` contains transparent PNG character cutouts.
- `icons/` contains transparent circular icon assets.
- `decorations/` contains non-interactive decorative artwork.
- `backgrounds/` contains visual scene references and partial crops.

The reference screenshot is flattened. Do not attempt to use it as a single background image or as clickable regions.

## PRIMARY OBJECTIVE

Redesign the Visitor Entry screen so it visually resembles the supplied museum entry reference while remaining a real, responsive, accessible Jetpack Compose interface.

The screen must clearly support:
1. Guest entry.
2. Student entry/login.
3. Administrator login as a separate lower-priority action.

The existing repository behavior and routes remain the source of truth. Reuse existing destinations and callbacks instead of inventing backend flows.

## REQUIRED LAYER ARCHITECTURE

Build the screen using a root `Box` or another suitable layered Compose structure.

Recommended z-order:

1. Full-screen background.
2. Decorative leaves, grass, dots, or other non-interactive artwork.
3. Character illustrations.
4. Native Compose role cards.
5. Native Compose labels, icons, buttons, and accessibility semantics.

Do not bake text into images.

Do not use image maps.

Do not make click handling depend on transparent pixels.

Do not put the entire screen inside one clickable composable.

## CLICKABLE AREAS

Each action must be a native Compose click target with a meaningful minimum touch target.

Guest:
- The complete Guest card/button is clickable.
- Navigate to the existing Guest Information flow.

Student:
- The complete Student card/button is clickable.
- Use the existing Student login/entry destination.
- If the existing UX already provides registration separately, preserve that route and expose it according to the current navigation architecture rather than removing it.

Administrator Login:
- Keep this visually separate and lower priority.
- Reuse the existing administrator login route.
- Do not expose administrator-only controls in the visitor interface.

If a top `Sign in as` control is retained, it must be a real semantic button and use an existing route or account-selection behavior. Do not create a dead button.

## VISUAL TARGET

Recreate the design language of the supplied reference:
- welcoming museum/campus atmosphere;
- soft green palette;
- large rounded cards;
- illustrated female guest and male student;
- floating or layered composition;
- soft shadows/elevation;
- clean professional typography;
- comfortable spacing;
- strong visual distinction between Guest, Student, and Administrator Login.

However, native Compose layout quality is more important than pixel-for-pixel copying.

## RESPONSIVENESS

The design must work at minimum on:
- 320 dp width;
- 360 dp width;
- 411 dp width;
- common portrait phone heights;
- system font scale 1.0 and 1.3.

Do not hardcode a layout that only matches one screenshot.

Avoid overlap between cards, characters, system bars, and buttons.

Use Scaffold/window insets correctly.

Use `statusBarsPadding()`, `navigationBarsPadding()`, or Scaffold inner padding where appropriate.

Allow vertical scrolling when the available height is insufficient.

## ASSET HANDLING

Copy the new assets into the Android runtime assets directory, preferably under a focused folder such as:

`android/app/src/main/assets/visitor_entry/`

Create or extend the existing asset constants/helper rather than scattering raw URI strings.

Example:
`file:///android_asset/visitor_entry/characters/char_guest_female.png`

Load raster assets with Coil.

Use:
- `ContentScale.Fit` for character illustrations;
- no stretching;
- `contentDescription = null` for purely decorative artwork;
- meaningful content descriptions where an image communicates account type.

Keep standard Material icons as vector icons when the project already has them.

## TRANSPARENCY

Respect the alpha channel of:
- `char_guest_female.png`
- `char_student_male.png`
- the role icon PNGs.

Do not place opaque rectangular backgrounds behind transparent character images unless required by the card design.

Do not flatten the characters into the scene background.

Characters should remain independent composables so their placement can adapt to screen size.

## COMPOSE IMPLEMENTATION QUALITY

Use:
- unidirectional state flow;
- existing ViewModels and navigation;
- lifecycle-aware state collection;
- stable state across recomposition;
- no network calls directly from composables.

Do not rewrite unrelated working screens.

Do not duplicate authentication logic.

Do not use fragile absolute pixel positioning as the primary layout strategy.

Use modifiers, constraints, alignment, weights, Box/Column/Row, and adaptive size calculations.

## ACCESSIBILITY

Every actionable element must:
- have a semantic role;
- have a meaningful accessible label;
- meet a reasonable touch target;
- remain reachable with TalkBack;
- not rely only on color to communicate its purpose.

Decorative layers must not create unnecessary accessibility noise.

## TESTING

Add or update tests for:
1. Visitor Entry displays Guest action.
2. Visitor Entry displays Student action.
3. Visitor Entry displays Administrator Login action.
4. Guest action invokes/navigates to the existing guest route.
5. Student action invokes/navigates to the existing student route.
6. Administrator Login invokes the existing admin route.
7. The layout does not require the character image itself to be clicked.
8. Narrow-width layout remains usable.
9. Font scale 1.3 remains usable.
10. Existing administrator regression behavior remains unchanged.

Run the relevant Android tests and build commands already supported by the repository.

Do not claim tests passed unless they actually passed.

## DELIVERABLE

Before editing:
1. Inspect the existing VisitorEntryScreen, VisitorNavGraph/routes, VisitorAssets, guest/student screens, and relevant tests.
2. Provide a concise implementation plan.
3. Then implement the redesign.

After implementation, report:
- files changed;
- assets copied and final Android paths;
- existing routes reused;
- clickable areas and navigation behavior;
- responsive behavior;
- accessibility considerations;
- exact test commands run;
- exact results;
- unresolved issues, if any.

Be conservative with existing architecture and aggressive about UI polish.

START NOW.
